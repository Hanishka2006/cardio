# Import necessary libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import joblib


data = pd.read_csv('D:/packages/stunt2.csv')


# Display the first few rows of the data
print(data.head())

# Display summary information of the data
print(data.info())

# Display statistical summary of the data
print(data.describe())


# Load the data
data = pd.read_csv('D:/packages/stunt2.csv')

# Handle missing values using forward fill (ffill)
data.ffill(inplace=True)

# Display the first few rows to check the data
print(data.head())

# Fill missing values with the mean of the column
data.fillna(data.mean(), inplace=True)






categorical_columns = ['sex', 'cp', 'fbs', 'restecg', 'exang', 'slope', 'ca', 'thal']
for col in categorical_columns:
    if col in data.columns:
        data = pd.get_dummies(data, columns=[col])
    else:
        print(f"Column '{col}' does not exist in the DataFrame.")





# Split the data into features and target variable
X = data.drop('target', axis=1)
y = data['target']


scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)



#visualize the correlation matrix
plt.figure(figsize=(12, 10))
sns.heatmap(data.corr(), annot=True, cmap='coolwarm', fmt='.2f')
plt.title('Correlation Matrix')
plt.show()


# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)


# Initialize the Logistic Regression model
model = LogisticRegression()


# Train the model
model.fit(X_train, y_train)

#feature selection
feature_importance = model.coef_[0]
feature_importance = 100.0 * (feature_importance / feature_importance.max())
sorted_idx = np.argsort(feature_importance)
pos = np.arange(sorted_idx.shape[0]) + .5
plt.figure(figsize=(12, 6))
plt.barh(pos, feature_importance[sorted_idx], align='center')
plt.yticks(pos, np.array(X.columns)[sorted_idx])
plt.xlabel('Relative Importance')
plt.title('Variable Importance')
plt.show()


#model prediction
#train test split
y_pred_train = model.predict(X_train)
y_pred_test = model.predict(X_test)


#model training
# Evaluate the model
train_accuracy = accuracy_score(y_train, y_pred_train)
test_accuracy = accuracy_score(y_test, y_pred_test)

print(f"Training Accuracy: {train_accuracy}")
print(f"Testing Accuracy: {test_accuracy}")

#model interpretation
#interpret the model
print(classification_report(y_test, y_pred_test))
print(confusion_matrix(y_test, y_pred_test))


# Save the model to a file
joblib.dump(model, 'heart_disease_model.pkl')

# Load the model from the file
loaded_model = joblib.load('heart_disease_model.pkl')


# Make predictions using the loaded model
new_data = X_test[:5]
predictions = loaded_model.predict(new_data)
print(predictions)
