import pandas as pd
import os

# Specify the correct path to your file
file_path = 'D:/packages/stunt2.csv'

# Check if the file exists
if os.path.exists(file_path):
    print("File exists")

    # Read the CSV file
    data = pd.read_csv(file_path)

    # Print the first few rows to verify successful loading
    print(data.head())
else:
    print("File does not exist. Please check the file path.")
